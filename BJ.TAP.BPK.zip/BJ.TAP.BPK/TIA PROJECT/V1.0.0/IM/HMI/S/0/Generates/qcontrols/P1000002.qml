﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777218
	objId: 16777218
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiGraphicView
	{
		id: q301989934
		objId: 301989934
		x: 593
		y: 20
		width: 189
		height: 260
		qm_Transparent : true 
		qm_ImageWidth: 189
		qm_ImageHeight: 260
		qm_SourceSizeWidth: 189
		qm_SourceSizeHeight: 260
	}
	IGuiGraphicView
	{
		id: q301989933
		objId: 301989933
		x: 592
		y: 275
		width: 189
		height: 185
		qm_Transparent : true 
		qm_ImageWidth: 189
		qm_ImageHeight: 185
		qm_SourceSizeWidth: 189
		qm_SourceSizeHeight: 185
	}
	IGuiGraphicView
	{
		id: q301989927
		objId: 301989927
		x: 313
		y: 257
		width: 286
		height: 208
		qm_Transparent : true 
		qm_ImageWidth: 286
		qm_ImageHeight: 208
		qm_SourceSizeWidth: 286
		qm_SourceSizeHeight: 208
	}
	IGuiGraphicView
	{
		id: q301989922
		objId: 301989922
		x: 301
		y: 3
		width: 298
		height: 256
		qm_Transparent : true 
		qm_ImageWidth: 298
		qm_ImageHeight: 256
		qm_SourceSizeWidth: 298
		qm_SourceSizeHeight: 256
	}
	IGuiGraphicView
	{
		id: q301989921
		objId: 301989921
		x: 14
		y: 3
		width: 305
		height: 476
		qm_Transparent : true 
		qm_ImageWidth: 305
		qm_ImageHeight: 476
		qm_SourceSizeWidth: 305
		qm_SourceSizeHeight: 476
	}
	IGuiQmlRectangle
	{
		id: q671088662
		objId: 671088662
		x: 0
		y: 461
		width: 799
		height: 18
		qm_BorderWidth: 1
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 799
		qm_RectangleHeight: 18
	}
	IGuiQmlRectangle
	{
		id: q671088663
		objId: 671088663
		x: 0
		y: 0
		width: 18
		height: 479
		qm_BorderWidth: 0
		qm_TextColor: "#ffffffff"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 18
		qm_RectangleHeight: 479
	}
	IGuiQmlRectangle
	{
		id: q671088664
		objId: 671088664
		x: 782
		y: 0
		width: 18
		height: 479
		qm_BorderWidth: 0
		qm_TextColor: "#ffffffff"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 18
		qm_RectangleHeight: 479
	}
	IGuiQmlRectangle
	{
		id: q671088665
		objId: 671088665
		x: 7
		y: 0
		width: 786
		height: 18
		qm_BorderWidth: 0
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 786
		qm_RectangleHeight: 18
	}
	IGuiTextField
	{
		id: q268435527
		objId: 268435527
		x: 117
		y: 25
		width: 89
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435528
		objId: 268435528
		x: 390
		y: 317
		width: 127
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098763
		objId: 369098763
		x: 362
		y: 340
		width: 175
		height: 50
		IGuiGraphicView
		{
			id: q301989923
			objId: 301989923
			x: 0
			y: 0
			width: 175
			height: 50
			qm_Transparent : true 
			qm_ImageWidth: 175
			qm_ImageHeight: 50
			qm_SourceSizeWidth: 175
			qm_SourceSizeHeight: 50
		}
		IGuiIOField
		{
			id: q33554456
			objId: 33554456
			x: 0
			y: 0
			width: 175
			height: 25
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435531
			objId: 268435531
			x: 0
			y: 25
			width: 175
			height: 25
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435530
		objId: 268435530
		x: 418
		y: 389
		width: 66
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088667
		objId: 671088667
		x: 314
		y: 256
		width: 279
		height: 205
		qm_BorderWidth: 9
		qm_TextColor: "#ff31cfce"
		qm_Transparent : true 
		qm_RectangleWidth: 279
		qm_RectangleHeight: 205
	}
	IGuiContainer
	{
		id: q369098762
		objId: 369098762
		x: 629
		y: 54
		width: 116
		height: 50
		IGuiGraphicView
		{
			id: q301989924
			objId: 301989924
			x: 0
			y: 0
			width: 116
			height: 50
			qm_Transparent : true 
			qm_ImageWidth: 116
			qm_ImageHeight: 50
			qm_SourceSizeWidth: 116
			qm_SourceSizeHeight: 50
		}
		IGuiIOField
		{
			id: q33554458
			objId: 33554458
			x: 0
			y: 0
			width: 116
			height: 25
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435532
			objId: 268435532
			x: 0
			y: 25
			width: 116
			height: 25
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435529
		objId: 268435529
		x: 619
		y: 29
		width: 143
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088666
		objId: 671088666
		x: 18
		y: 18
		width: 296
		height: 443
		qm_BorderWidth: 9
		qm_TextColor: "#ffff6500"
		qm_Transparent : true 
		qm_RectangleWidth: 296
		qm_RectangleHeight: 443
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544346
		objId: 335544346
		x: 31
		y: 73
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435533
		objId: 268435533
		x: 71
		y: 49
		width: 186
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435534
		objId: 268435534
		x: 51
		y: 74
		width: 75
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544347
		objId: 335544347
		x: 31
		y: 99
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435535
		objId: 268435535
		x: 51
		y: 94
		width: 72
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544348
		objId: 335544348
		x: 155
		y: 72
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435536
		objId: 268435536
		x: 175
		y: 74
		width: 118
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544349
		objId: 335544349
		x: 155
		y: 94
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435537
		objId: 268435537
		x: 175
		y: 96
		width: 99
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544350
		objId: 335544350
		x: 155
		y: 121
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435538
		objId: 268435538
		x: 175
		y: 117
		width: 87
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435539
		objId: 268435539
		x: 71
		y: 158
		width: 188
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539296
		objId: 486539296
		x: 132
		y: 221
		width: 92
		height: 39
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/62#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiTextField
	{
		id: q268435540
		objId: 268435540
		x: 38
		y: 187
		width: 82
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435541
		objId: 268435541
		x: 144
		y: 187
		width: 66
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435542
		objId: 268435542
		x: 235
		y: 186
		width: 62
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435543
		objId: 268435543
		x: 50
		y: 339
		width: 224
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554459
		objId: 33554459
		x: 33
		y: 286
		width: 53
		height: 32
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
	}
	IGuiTextField
	{
		id: q268435544
		objId: 268435544
		x: 87
		y: 286
		width: 88
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098764
		objId: 369098764
		x: 27
		y: 364
		width: 104
		height: 52
		IGuiGraphicView
		{
			id: q301989925
			objId: 301989925
			x: 0
			y: 0
			width: 104
			height: 52
			qm_Transparent : true 
			qm_ImageWidth: 104
			qm_ImageHeight: 52
			qm_SourceSizeWidth: 104
			qm_SourceSizeHeight: 52
		}
		IGuiIOField
		{
			id: q33554460
			objId: 33554460
			x: 0
			y: 0
			width: 104
			height: 26
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435545
			objId: 268435545
			x: 0
			y: 26
			width: 104
			height: 26
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435546
		objId: 268435546
		x: 36
		y: 412
		width: 80
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098765
		objId: 369098765
		x: 139
		y: 364
		width: 141
		height: 52
		IGuiGraphicView
		{
			id: q301989926
			objId: 301989926
			x: 0
			y: 0
			width: 141
			height: 52
			qm_Transparent : true 
			qm_ImageWidth: 141
			qm_ImageHeight: 52
			qm_SourceSizeWidth: 141
			qm_SourceSizeHeight: 52
		}
		IGuiIOField
		{
			id: q33554461
			objId: 33554461
			x: 0
			y: 0
			width: 141
			height: 26
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435547
			objId: 268435547
			x: 0
			y: 26
			width: 141
			height: 26
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435548
		objId: 268435548
		x: 160
		y: 412
		width: 98
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088670
		objId: 671088670
		x: 312
		y: 18
		width: 280
		height: 238
		qm_BorderWidth: 9
		qm_TextColor: "#ffff6500"
		qm_Transparent : true 
		qm_RectangleWidth: 280
		qm_RectangleHeight: 238
	}
	IGuiContainer
	{
		id: q369098766
		objId: 369098766
		x: 327
		y: 29
		width: 99
		height: 47
		IGuiGraphicView
		{
			id: q301989928
			objId: 301989928
			x: 0
			y: 0
			width: 99
			height: 47
			qm_Transparent : true 
			qm_ImageWidth: 99
			qm_ImageHeight: 47
			qm_SourceSizeWidth: 99
			qm_SourceSizeHeight: 47
		}
		IGuiIOField
		{
			id: q33554462
			objId: 33554462
			x: 0
			y: 0
			width: 99
			height: 24
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435549
			objId: 268435549
			x: 0
			y: 23
			width: 99
			height: 24
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435550
		objId: 268435550
		x: 341
		y: 71
		width: 71
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098767
		objId: 369098767
		x: 439
		y: 29
		width: 135
		height: 46
		IGuiGraphicView
		{
			id: q301989929
			objId: 301989929
			x: 0
			y: 0
			width: 135
			height: 46
			qm_Transparent : true 
			qm_ImageWidth: 135
			qm_ImageHeight: 46
			qm_SourceSizeWidth: 135
			qm_SourceSizeHeight: 46
		}
		IGuiIOField
		{
			id: q33554463
			objId: 33554463
			x: 0
			y: 0
			width: 135
			height: 23
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435551
			objId: 268435551
			x: 0
			y: 23
			width: 135
			height: 23
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435552
		objId: 268435552
		x: 460
		y: 71
		width: 90
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098768
		objId: 369098768
		x: 327
		y: 88
		width: 99
		height: 45
		IGuiGraphicView
		{
			id: q301989930
			objId: 301989930
			x: 0
			y: 0
			width: 99
			height: 45
			qm_Transparent : true 
			qm_ImageWidth: 99
			qm_ImageHeight: 45
			qm_SourceSizeWidth: 99
			qm_SourceSizeHeight: 45
		}
		IGuiIOField
		{
			id: q33554464
			objId: 33554464
			x: 0
			y: 0
			width: 99
			height: 22
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435553
			objId: 268435553
			x: 0
			y: 22
			width: 99
			height: 22
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435554
		objId: 268435554
		x: 345
		y: 130
		width: 57
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098769
		objId: 369098769
		x: 439
		y: 88
		width: 142
		height: 47
		IGuiGraphicView
		{
			id: q301989931
			objId: 301989931
			x: 0
			y: 0
			width: 142
			height: 47
			qm_Transparent : true 
			qm_ImageWidth: 142
			qm_ImageHeight: 47
			qm_SourceSizeWidth: 142
			qm_SourceSizeHeight: 47
		}
		IGuiIOField
		{
			id: q33554465
			objId: 33554465
			x: 0
			y: 0
			width: 142
			height: 24
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435556
		objId: 268435556
		x: 468
		y: 130
		width: 81
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098770
		objId: 369098770
		x: 324
		y: 174
		width: 135
		height: 43
		IGuiGraphicView
		{
			id: q301989932
			objId: 301989932
			x: 0
			y: 0
			width: 135
			height: 43
			qm_Transparent : true 
			qm_ImageWidth: 135
			qm_ImageHeight: 43
			qm_SourceSizeWidth: 135
			qm_SourceSizeHeight: 43
		}
		IGuiIOField
		{
			id: q33554466
			objId: 33554466
			x: 0
			y: 0
			width: 135
			height: 22
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435558
		objId: 268435558
		x: 345
		y: 216
		width: 95
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088669
		objId: 671088669
		x: 593
		y: 275
		width: 188
		height: 186
		qm_BorderWidth: 9
		qm_TextColor: "#ffff0000"
		qm_Transparent : true 
		qm_RectangleWidth: 188
		qm_RectangleHeight: 186
	}
	IGuiQmlRectangle
	{
		id: q671088668
		objId: 671088668
		x: 593
		y: 18
		width: 189
		height: 258
		qm_BorderWidth: 9
		qm_TextColor: "#ff9ccf00"
		qm_Transparent : true 
		qm_RectangleWidth: 189
		qm_RectangleHeight: 258
	}
	IGuiIOField
	{
		id: q33554457
		objId: 33554457
		x: 178
		y: 288
		width: 53
		height: 32
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
	}
	IGuiTextField
	{
		id: q268435559
		objId: 268435559
		x: 232
		y: 288
		width: 68
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544351
		objId: 335544351
		x: 639
		y: 180
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544352
		objId: 335544352
		x: 639
		y: 232
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544353
		objId: 335544353
		x: 639
		y: 202
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435560
		objId: 268435560
		x: 664
		y: 232
		width: 69
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435561
		objId: 268435561
		x: 666
		y: 201
		width: 63
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435562
		objId: 268435562
		x: 665
		y: 180
		width: 63
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544354
		objId: 335544354
		x: 639
		y: 160
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435563
		objId: 268435563
		x: 665
		y: 160
		width: 68
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435564
		objId: 268435564
		x: 665
		y: 139
		width: 62
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544355
		objId: 335544355
		x: 639
		y: 139
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435565
		objId: 268435565
		x: 665
		y: 106
		width: 62
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544356
		objId: 335544356
		x: 639
		y: 106
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435566
		objId: 268435566
		x: 600
		y: 337
		width: 76
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098771
		objId: 369098771
		x: 602
		y: 284
		width: 92
		height: 57
		IGuiGraphicView
		{
			id: q301989935
			objId: 301989935
			x: 0
			y: 0
			width: 92
			height: 57
			qm_Transparent : true 
			qm_ImageWidth: 92
			qm_ImageHeight: 57
			qm_SourceSizeWidth: 92
			qm_SourceSizeHeight: 57
		}
		IGuiIOField
		{
			id: q33554467
			objId: 33554467
			x: 0
			y: 0
			width: 92
			height: 28
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435567
			objId: 268435567
			x: 0
			y: 28
			width: 92
			height: 28
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiGraphicView
	{
		id: q301989936
		objId: 301989936
		x: 664
		y: 410
		width: 40
		height: 40
		qm_Transparent : true 
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicView
	{
		id: q301989937
		objId: 301989937
		x: 709
		y: 411
		width: 40
		height: 40
		qm_Transparent : true 
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiTextField
	{
		id: q268435568
		objId: 268435568
		x: 688
		y: 338
		width: 83
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539297
		objId: 486539297
		x: 666
		y: 411
		width: 40
		height: 40
		qm_BorderWidth: 5
		qm_RectangleBorder.width:5
		qm_RectangleBorder.color:"#ffe7e3e7"
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiButton
	{
		id: q486539298
		objId: 486539298
		x: 708
		y: 411
		width: 40
		height: 40
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/67#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiIOField
	{
		id: q33554468
		objId: 33554468
		x: 706
		y: 288
		width: 53
		height: 47
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
	}
	IGuiButton
	{
		id: q486539299
		objId: 486539299
		x: 34
		y: 128
		width: 92
		height: 27
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/62#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiButton
	{
		id: q486539300
		objId: 486539300
		x: 33
		y: 221
		width: 92
		height: 39
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/62#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiIOField
	{
		id: q33554469
		objId: 33554469
		x: 240
		y: 222
		width: 53
		height: 38
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544357
		objId: 335544357
		x: 471
		y: 174
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544358
		objId: 335544358
		x: 471
		y: 206
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435569
		objId: 268435569
		x: 491
		y: 166
		width: 87
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435570
		objId: 268435570
		x: 492
		y: 201
		width: 72
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicView
	{
		id: q301989938
		objId: 301989938
		x: 621
		y: 412
		width: 40
		height: 40
		qm_Transparent : true 
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiButton
	{
		id: q486539301
		objId: 486539301
		x: 621
		y: 412
		width: 40
		height: 40
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/67#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
}
