﻿import QtQuick 2.7
import "qrc:/"
IGuiDialogView
{
	id: q687865856
	objId: 687865856
	x: 160
	y: 126
	width: 480
	height: 228
	qm_BorderWidth: 1
	qm_RectangleBorder.color:"#ff1c1f30"
	qm_FillColor: "#fff4f4f5"
	z:245
	captionrectX: 0
	captionrectY: 0
	captionrectWidth: 480
	captionrectHeight: 34
	captionrectBackgroundColor: "#ff3e414f"
	captionrectForegroundColor: "#ffffffff"
	captionTextX: 12
	captionTextY: 8
	captionTextWidth: 230
	captionTextHeight: 20
	qm_DisplayText: "Login"
	modalityWidth: 320
	modalityHeight: 252
	IGuiModality{ }
	IGuiTextField
	{
		id: q268435571
		objId: 268435571
		x: 92
		y: 103
		width: 100
		height: 22
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#fff5f5f5"
		qm_FillColor: "#fff4f4f5"
		qm_TextColor: "#ff3e414f"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignRight
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 1
		qm_Anchors.leftMargin: 1
		qm_Anchors.rightMargin: 1
		qm_Anchors.topMargin: 1
	}
	IGuiIOField
	{
		id: q33554470
		objId: 33554470
		x: 200
		y: 103
		width: 264
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ffb7b8b8"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff3e414f"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 9
		qm_Anchors.rightMargin: 17
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435572
		objId: 268435572
		x: 92
		y: 137
		width: 100
		height: 22
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#fff5f5f5"
		qm_FillColor: "#fff4f4f5"
		qm_TextColor: "#ff3e414f"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignRight
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 1
		qm_Anchors.leftMargin: 1
		qm_Anchors.rightMargin: 1
		qm_Anchors.topMargin: 1
	}
	IGuiIOField
	{
		id: q33554471
		objId: 33554471
		x: 200
		y: 137
		width: 264
		height: 22
		qm_BorderCornerRadius: 3
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ffb7b8b8"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff3e414f"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 9
		qm_Anchors.rightMargin: 17
		qm_Anchors.topMargin: 2
		qm_passwordMode: true
	}
	IGuiButton
	{
		id: q486539302
		objId: 486539302
		x: 383
		y: 194
		width: 97
		height: 34
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/8#2#4#128#0#0"
		qm_Border.top: 15
		qm_Border.bottom: 15
		qm_Border.right: 2
		qm_Border.left: 2
		qm_FillColor: "#ff494c59"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff55bfff"
	}
	IGuiButton
	{
		id: q486539303
		objId: 486539303
		x: 287
		y: 194
		width: 97
		height: 34
		qm_BorderWidth: 1
		qm_ImageSource: "image://QSmartImageProvider/69#2#4#128#0#0"
		qm_Border.top: 12
		qm_Border.bottom: 12
		qm_Border.right: 2
		qm_Border.left: 2
		qm_FillColor: "#ff494c59"
		qm_TextColor: "#ffffffff"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff55bfff"
	}
	IGuiGraphicButton
	{
		id: q486539304
		objId: 486539304
		x: 446
		y: 0
		width: 34
		height: 34
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff1c1f30"
		qm_FillColor: "#ff464b5a"
		qm_FocusWidth: 2
		qm_FocusColor: "#ff55bfff"
		qm_ImageFillMode:6
		qm_ImagePossitionX: 2
		qm_ImagePossitionY: 2
		qm_ImageWidth: 30
		qm_ImageHeight: 30
		qm_SourceSizeWidth: 30
		qm_SourceSizeHeight: 30
	}
	IGuiQmlRectangle
	{
		id: q671088671
		objId: 671088671
		x: 0
		y: 194
		width: 478
		height: 34
		qm_BorderWidth: 0
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff3e414f"
		qm_RectangleWidth: 478
		qm_RectangleHeight: 34
	}
}
