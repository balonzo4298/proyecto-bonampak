﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777219
	objId: 16777219
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiQmlRectangle
	{
		id: q671088672
		objId: 671088672
		x: 0
		y: 461
		width: 799
		height: 18
		qm_BorderWidth: 1
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 799
		qm_RectangleHeight: 18
	}
	IGuiQmlRectangle
	{
		id: q671088673
		objId: 671088673
		x: 0
		y: 0
		width: 18
		height: 479
		qm_BorderWidth: 0
		qm_TextColor: "#ffffffff"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 18
		qm_RectangleHeight: 479
	}
	IGuiQmlRectangle
	{
		id: q671088674
		objId: 671088674
		x: 782
		y: 0
		width: 18
		height: 479
		qm_BorderWidth: 0
		qm_TextColor: "#ffffffff"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 18
		qm_RectangleHeight: 479
	}
	IGuiQmlRectangle
	{
		id: q671088675
		objId: 671088675
		x: 7
		y: 0
		width: 786
		height: 18
		qm_BorderWidth: 0
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 786
		qm_RectangleHeight: 18
	}
	IGuiQmlRectangle
	{
		id: q671088676
		objId: 671088676
		x: 18
		y: 18
		width: 241
		height: 443
		qm_BorderWidth: 9
		qm_TextColor: "#ffff6500"
		qm_Transparent : true 
		qm_RectangleWidth: 241
		qm_RectangleHeight: 443
	}
	IGuiTextField
	{
		id: q268435573
		objId: 268435573
		x: 78
		y: 27
		width: 114
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544359
		objId: 335544359
		x: 50
		y: 56
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435574
		objId: 268435574
		x: 70
		y: 57
		width: 22
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544360
		objId: 335544360
		x: 50
		y: 98
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435575
		objId: 268435575
		x: 70
		y: 100
		width: 57
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544361
		objId: 335544361
		x: 50
		y: 77
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435576
		objId: 268435576
		x: 70
		y: 78
		width: 43
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544362
		objId: 335544362
		x: 50
		y: 119
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435577
		objId: 268435577
		x: 70
		y: 121
		width: 38
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544363
		objId: 335544363
		x: 156
		y: 56
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435578
		objId: 268435578
		x: 177
		y: 58
		width: 57
		height: 17
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544364
		objId: 335544364
		x: 156
		y: 78
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544365
		objId: 335544365
		x: 156
		y: 99
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435579
		objId: 268435579
		x: 176
		y: 79
		width: 57
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435580
		objId: 268435580
		x: 177
		y: 100
		width: 45
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539305
		objId: 486539305
		x: 34
		y: 170
		width: 61
		height: 24
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ff0000ff"
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544366
		objId: 335544366
		x: 156
		y: 120
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435581
		objId: 268435581
		x: 177
		y: 122
		width: 52
		height: 17
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435582
		objId: 268435582
		x: 39
		y: 146
		width: 169
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435583
		objId: 268435583
		x: 31
		y: 194
		width: 67
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088677
		objId: 671088677
		x: 18
		y: 140
		width: 234
		height: 9
		qm_BorderWidth: 0
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ffff6500"
		qm_RectangleWidth: 234
		qm_RectangleHeight: 9
	}
	IGuiButton
	{
		id: q486539306
		objId: 486539306
		x: 116
		y: 170
		width: 100
		height: 24
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ff0000ff"
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiTextField
	{
		id: q268435584
		objId: 268435584
		x: 126
		y: 196
		width: 82
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539307
		objId: 486539307
		x: 42
		y: 224
		width: 40
		height: 40
		qm_BorderCornerRadius: 20
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ff0000ff"
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 3
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 3
		qm_Anchors.topMargin: 3
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiTextField
	{
		id: q268435585
		objId: 268435585
		x: 37
		y: 264
		width: 50
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554472
		objId: 33554472
		x: 32
		y: 283
		width: 97
		height: 30
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ff0000ff"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiIOField
	{
		id: q33554473
		objId: 33554473
		x: 114
		y: 229
		width: 100
		height: 25
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ff0000ff"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiTextField
	{
		id: q268435586
		objId: 268435586
		x: 116
		y: 255
		width: 101
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554474
		objId: 33554474
		x: 152
		y: 283
		width: 94
		height: 30
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ff0000ff"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiTextField
	{
		id: q268435587
		objId: 268435587
		x: 29
		y: 312
		width: 102
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435588
		objId: 268435588
		x: 164
		y: 312
		width: 69
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554475
		objId: 33554475
		x: 31
		y: 330
		width: 76
		height: 24
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ffff0000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiIOField
	{
		id: q33554476
		objId: 33554476
		x: 31
		y: 355
		width: 76
		height: 24
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ffff0000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiIOField
	{
		id: q33554477
		objId: 33554477
		x: 31
		y: 380
		width: 76
		height: 24
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ffff0000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiIOField
	{
		id: q33554478
		objId: 33554478
		x: 31
		y: 405
		width: 76
		height: 24
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ffff0000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiIOField
	{
		id: q33554479
		objId: 33554479
		x: 31
		y: 430
		width: 76
		height: 24
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ffff0000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiTextField
	{
		id: q268435589
		objId: 268435589
		x: 108
		y: 327
		width: 47
		height: 30
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435590
		objId: 268435590
		x: 109
		y: 351
		width: 50
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435591
		objId: 268435591
		x: 107
		y: 383
		width: 64
		height: 17
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435592
		objId: 268435592
		x: 107
		y: 407
		width: 60
		height: 17
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435593
		objId: 268435593
		x: 108
		y: 424
		width: 53
		height: 30
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554480
		objId: 33554480
		x: 179
		y: 337
		width: 65
		height: 25
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ffff0000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiTextField
	{
		id: q268435594
		objId: 268435594
		x: 180
		y: 362
		width: 65
		height: 30
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554481
		objId: 33554481
		x: 179
		y: 394
		width: 65
		height: 25
		qm_BorderWidth: 3
		qm_RectangleBorder.width:3
		qm_RectangleBorder.color:"#ffff0000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
	}
	IGuiTextField
	{
		id: q268435595
		objId: 268435595
		x: 181
		y: 419
		width: 55
		height: 17
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
}
