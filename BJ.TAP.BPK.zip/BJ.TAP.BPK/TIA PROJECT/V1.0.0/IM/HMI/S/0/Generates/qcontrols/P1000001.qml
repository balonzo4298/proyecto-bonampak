﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777217
	objId: 16777217
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiGraphicView
	{
		id: q301989917
		objId: 301989917
		x: 593
		y: 20
		width: 189
		height: 260
		qm_Transparent : true 
		qm_ImageWidth: 189
		qm_ImageHeight: 260
		qm_SourceSizeWidth: 189
		qm_SourceSizeHeight: 260
	}
	IGuiGraphicView
	{
		id: q301989916
		objId: 301989916
		x: 592
		y: 275
		width: 189
		height: 185
		qm_Transparent : true 
		qm_ImageWidth: 189
		qm_ImageHeight: 185
		qm_SourceSizeWidth: 189
		qm_SourceSizeHeight: 185
	}
	IGuiGraphicView
	{
		id: q301989910
		objId: 301989910
		x: 313
		y: 257
		width: 286
		height: 208
		qm_Transparent : true 
		qm_ImageWidth: 286
		qm_ImageHeight: 208
		qm_SourceSizeWidth: 286
		qm_SourceSizeHeight: 208
	}
	IGuiGraphicView
	{
		id: q301989905
		objId: 301989905
		x: 301
		y: 3
		width: 298
		height: 256
		qm_Transparent : true 
		qm_ImageWidth: 298
		qm_ImageHeight: 256
		qm_SourceSizeWidth: 298
		qm_SourceSizeHeight: 256
	}
	IGuiGraphicView
	{
		id: q301989904
		objId: 301989904
		x: 14
		y: 3
		width: 305
		height: 476
		qm_Transparent : true 
		qm_ImageWidth: 305
		qm_ImageHeight: 476
		qm_SourceSizeWidth: 305
		qm_SourceSizeHeight: 476
	}
	IGuiQmlRectangle
	{
		id: q671088653
		objId: 671088653
		x: 0
		y: 461
		width: 799
		height: 18
		qm_BorderWidth: 1
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 799
		qm_RectangleHeight: 18
	}
	IGuiQmlRectangle
	{
		id: q671088654
		objId: 671088654
		x: 0
		y: 0
		width: 18
		height: 479
		qm_BorderWidth: 0
		qm_TextColor: "#ffffffff"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 18
		qm_RectangleHeight: 479
	}
	IGuiQmlRectangle
	{
		id: q671088655
		objId: 671088655
		x: 782
		y: 0
		width: 18
		height: 479
		qm_BorderWidth: 0
		qm_TextColor: "#ffffffff"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 18
		qm_RectangleHeight: 479
	}
	IGuiQmlRectangle
	{
		id: q671088656
		objId: 671088656
		x: 7
		y: 0
		width: 786
		height: 18
		qm_BorderWidth: 0
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 786
		qm_RectangleHeight: 18
	}
	IGuiTextField
	{
		id: q268435483
		objId: 268435483
		x: 117
		y: 25
		width: 89
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435484
		objId: 268435484
		x: 390
		y: 317
		width: 127
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098753
		objId: 369098753
		x: 362
		y: 340
		width: 175
		height: 50
		IGuiGraphicView
		{
			id: q301989906
			objId: 301989906
			x: 0
			y: 0
			width: 175
			height: 50
			qm_Transparent : true 
			qm_ImageWidth: 175
			qm_ImageHeight: 50
			qm_SourceSizeWidth: 175
			qm_SourceSizeHeight: 50
		}
		IGuiIOField
		{
			id: q33554442
			objId: 33554442
			x: 0
			y: 0
			width: 175
			height: 25
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435487
			objId: 268435487
			x: 0
			y: 25
			width: 175
			height: 25
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435486
		objId: 268435486
		x: 418
		y: 389
		width: 66
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088658
		objId: 671088658
		x: 314
		y: 256
		width: 279
		height: 205
		qm_BorderWidth: 9
		qm_TextColor: "#ff31cfce"
		qm_Transparent : true 
		qm_RectangleWidth: 279
		qm_RectangleHeight: 205
	}
	IGuiContainer
	{
		id: q369098752
		objId: 369098752
		x: 629
		y: 54
		width: 116
		height: 50
		IGuiGraphicView
		{
			id: q301989907
			objId: 301989907
			x: 0
			y: 0
			width: 116
			height: 50
			qm_Transparent : true 
			qm_ImageWidth: 116
			qm_ImageHeight: 50
			qm_SourceSizeWidth: 116
			qm_SourceSizeHeight: 50
		}
		IGuiIOField
		{
			id: q33554444
			objId: 33554444
			x: 0
			y: 0
			width: 116
			height: 25
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435488
			objId: 268435488
			x: 0
			y: 25
			width: 116
			height: 25
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435485
		objId: 268435485
		x: 619
		y: 29
		width: 143
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088657
		objId: 671088657
		x: 18
		y: 18
		width: 296
		height: 443
		qm_BorderWidth: 9
		qm_TextColor: "#ffff6500"
		qm_Transparent : true 
		qm_RectangleWidth: 296
		qm_RectangleHeight: 443
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544333
		objId: 335544333
		x: 31
		y: 73
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435489
		objId: 268435489
		x: 71
		y: 49
		width: 186
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435490
		objId: 268435490
		x: 51
		y: 74
		width: 75
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544334
		objId: 335544334
		x: 31
		y: 99
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435491
		objId: 268435491
		x: 51
		y: 94
		width: 72
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544335
		objId: 335544335
		x: 155
		y: 72
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435492
		objId: 268435492
		x: 175
		y: 74
		width: 118
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544336
		objId: 335544336
		x: 155
		y: 94
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435493
		objId: 268435493
		x: 175
		y: 96
		width: 99
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544337
		objId: 335544337
		x: 155
		y: 121
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435494
		objId: 268435494
		x: 175
		y: 117
		width: 87
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435495
		objId: 268435495
		x: 71
		y: 158
		width: 188
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539291
		objId: 486539291
		x: 132
		y: 221
		width: 92
		height: 39
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/62#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiTextField
	{
		id: q268435496
		objId: 268435496
		x: 38
		y: 187
		width: 82
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435497
		objId: 268435497
		x: 144
		y: 187
		width: 66
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435498
		objId: 268435498
		x: 235
		y: 186
		width: 62
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435499
		objId: 268435499
		x: 50
		y: 339
		width: 224
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554445
		objId: 33554445
		x: 33
		y: 286
		width: 53
		height: 32
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
	}
	IGuiTextField
	{
		id: q268435500
		objId: 268435500
		x: 87
		y: 286
		width: 88
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098754
		objId: 369098754
		x: 27
		y: 364
		width: 104
		height: 52
		IGuiGraphicView
		{
			id: q301989908
			objId: 301989908
			x: 0
			y: 0
			width: 104
			height: 52
			qm_Transparent : true 
			qm_ImageWidth: 104
			qm_ImageHeight: 52
			qm_SourceSizeWidth: 104
			qm_SourceSizeHeight: 52
		}
		IGuiIOField
		{
			id: q33554446
			objId: 33554446
			x: 0
			y: 0
			width: 104
			height: 26
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435501
			objId: 268435501
			x: 0
			y: 26
			width: 104
			height: 26
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435502
		objId: 268435502
		x: 36
		y: 412
		width: 80
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098755
		objId: 369098755
		x: 139
		y: 364
		width: 141
		height: 52
		IGuiGraphicView
		{
			id: q301989909
			objId: 301989909
			x: 0
			y: 0
			width: 141
			height: 52
			qm_Transparent : true 
			qm_ImageWidth: 141
			qm_ImageHeight: 52
			qm_SourceSizeWidth: 141
			qm_SourceSizeHeight: 52
		}
		IGuiIOField
		{
			id: q33554447
			objId: 33554447
			x: 0
			y: 0
			width: 141
			height: 26
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435503
			objId: 268435503
			x: 0
			y: 26
			width: 141
			height: 26
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435504
		objId: 268435504
		x: 160
		y: 412
		width: 98
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088661
		objId: 671088661
		x: 312
		y: 18
		width: 280
		height: 238
		qm_BorderWidth: 9
		qm_TextColor: "#ffff6500"
		qm_Transparent : true 
		qm_RectangleWidth: 280
		qm_RectangleHeight: 238
	}
	IGuiContainer
	{
		id: q369098756
		objId: 369098756
		x: 327
		y: 29
		width: 99
		height: 47
		IGuiGraphicView
		{
			id: q301989911
			objId: 301989911
			x: 0
			y: 0
			width: 99
			height: 47
			qm_Transparent : true 
			qm_ImageWidth: 99
			qm_ImageHeight: 47
			qm_SourceSizeWidth: 99
			qm_SourceSizeHeight: 47
		}
		IGuiIOField
		{
			id: q33554448
			objId: 33554448
			x: 0
			y: 0
			width: 99
			height: 24
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435505
			objId: 268435505
			x: 0
			y: 23
			width: 99
			height: 24
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435506
		objId: 268435506
		x: 341
		y: 71
		width: 71
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098757
		objId: 369098757
		x: 439
		y: 29
		width: 135
		height: 46
		IGuiGraphicView
		{
			id: q301989912
			objId: 301989912
			x: 0
			y: 0
			width: 135
			height: 46
			qm_Transparent : true 
			qm_ImageWidth: 135
			qm_ImageHeight: 46
			qm_SourceSizeWidth: 135
			qm_SourceSizeHeight: 46
		}
		IGuiIOField
		{
			id: q33554449
			objId: 33554449
			x: 0
			y: 0
			width: 135
			height: 23
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435507
			objId: 268435507
			x: 0
			y: 23
			width: 135
			height: 23
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435508
		objId: 268435508
		x: 460
		y: 71
		width: 90
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098758
		objId: 369098758
		x: 327
		y: 88
		width: 99
		height: 45
		IGuiGraphicView
		{
			id: q301989913
			objId: 301989913
			x: 0
			y: 0
			width: 99
			height: 45
			qm_Transparent : true 
			qm_ImageWidth: 99
			qm_ImageHeight: 45
			qm_SourceSizeWidth: 99
			qm_SourceSizeHeight: 45
		}
		IGuiIOField
		{
			id: q33554450
			objId: 33554450
			x: 0
			y: 0
			width: 99
			height: 22
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435509
			objId: 268435509
			x: 0
			y: 22
			width: 99
			height: 22
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435510
		objId: 268435510
		x: 345
		y: 130
		width: 57
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098759
		objId: 369098759
		x: 439
		y: 88
		width: 142
		height: 47
		IGuiGraphicView
		{
			id: q301989914
			objId: 301989914
			x: 0
			y: 0
			width: 142
			height: 47
			qm_Transparent : true 
			qm_ImageWidth: 142
			qm_ImageHeight: 47
			qm_SourceSizeWidth: 142
			qm_SourceSizeHeight: 47
		}
		IGuiIOField
		{
			id: q33554451
			objId: 33554451
			x: 0
			y: 0
			width: 142
			height: 24
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435512
		objId: 268435512
		x: 468
		y: 130
		width: 81
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098760
		objId: 369098760
		x: 324
		y: 174
		width: 135
		height: 43
		IGuiGraphicView
		{
			id: q301989915
			objId: 301989915
			x: 0
			y: 0
			width: 135
			height: 43
			qm_Transparent : true 
			qm_ImageWidth: 135
			qm_ImageHeight: 43
			qm_SourceSizeWidth: 135
			qm_SourceSizeHeight: 43
		}
		IGuiIOField
		{
			id: q33554452
			objId: 33554452
			x: 0
			y: 0
			width: 135
			height: 22
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiTextField
	{
		id: q268435514
		objId: 268435514
		x: 345
		y: 216
		width: 95
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiQmlRectangle
	{
		id: q671088660
		objId: 671088660
		x: 593
		y: 275
		width: 188
		height: 186
		qm_BorderWidth: 9
		qm_TextColor: "#ffff0000"
		qm_Transparent : true 
		qm_RectangleWidth: 188
		qm_RectangleHeight: 186
	}
	IGuiQmlRectangle
	{
		id: q671088659
		objId: 671088659
		x: 593
		y: 18
		width: 189
		height: 258
		qm_BorderWidth: 9
		qm_TextColor: "#ff9ccf00"
		qm_Transparent : true 
		qm_RectangleWidth: 189
		qm_RectangleHeight: 258
	}
	IGuiIOField
	{
		id: q33554443
		objId: 33554443
		x: 178
		y: 288
		width: 53
		height: 32
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
	}
	IGuiTextField
	{
		id: q268435515
		objId: 268435515
		x: 232
		y: 288
		width: 68
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544338
		objId: 335544338
		x: 639
		y: 180
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544339
		objId: 335544339
		x: 639
		y: 232
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544340
		objId: 335544340
		x: 639
		y: 202
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435516
		objId: 268435516
		x: 664
		y: 232
		width: 69
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435517
		objId: 268435517
		x: 666
		y: 201
		width: 63
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435518
		objId: 268435518
		x: 665
		y: 180
		width: 63
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544341
		objId: 335544341
		x: 639
		y: 160
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435519
		objId: 268435519
		x: 665
		y: 160
		width: 68
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435520
		objId: 268435520
		x: 665
		y: 139
		width: 62
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544342
		objId: 335544342
		x: 639
		y: 139
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435521
		objId: 268435521
		x: 665
		y: 106
		width: 62
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544343
		objId: 335544343
		x: 639
		y: 106
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435522
		objId: 268435522
		x: 600
		y: 337
		width: 76
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiContainer
	{
		id: q369098761
		objId: 369098761
		x: 602
		y: 284
		width: 92
		height: 57
		IGuiGraphicView
		{
			id: q301989918
			objId: 301989918
			x: 0
			y: 0
			width: 92
			height: 57
			qm_Transparent : true 
			qm_ImageWidth: 92
			qm_ImageHeight: 57
			qm_SourceSizeWidth: 92
			qm_SourceSizeHeight: 57
		}
		IGuiIOField
		{
			id: q33554453
			objId: 33554453
			x: 0
			y: 0
			width: 92
			height: 28
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_ValueVarTextAlignmentVertical: Text.AlignBottom
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
		IGuiTextField
		{
			id: q268435523
			objId: 268435523
			x: 0
			y: 28
			width: 92
			height: 28
			qm_Transparent : true 
			qm_TextColor: "#ff000000"
			qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
			qm_Anchors.bottomMargin: 2
			qm_Anchors.leftMargin: 2
			qm_Anchors.rightMargin: 2
			qm_Anchors.topMargin: 2
		}
	}
	IGuiGraphicView
	{
		id: q301989919
		objId: 301989919
		x: 664
		y: 410
		width: 40
		height: 40
		qm_Transparent : true 
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiGraphicView
	{
		id: q301989920
		objId: 301989920
		x: 709
		y: 411
		width: 40
		height: 40
		qm_Transparent : true 
		qm_ImageWidth: 40
		qm_ImageHeight: 40
		qm_SourceSizeWidth: 40
		qm_SourceSizeHeight: 40
	}
	IGuiTextField
	{
		id: q268435524
		objId: 268435524
		x: 688
		y: 338
		width: 83
		height: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiButton
	{
		id: q486539292
		objId: 486539292
		x: 666
		y: 411
		width: 40
		height: 40
		qm_BorderWidth: 5
		qm_RectangleBorder.width:5
		qm_RectangleBorder.color:"#ffe7e3e7"
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 5
		qm_Anchors.leftMargin: 5
		qm_Anchors.rightMargin: 5
		qm_Anchors.topMargin: 5
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiButton
	{
		id: q486539293
		objId: 486539293
		x: 708
		y: 411
		width: 40
		height: 40
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/67#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiIOField
	{
		id: q33554454
		objId: 33554454
		x: 706
		y: 288
		width: 53
		height: 47
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
	}
	IGuiButton
	{
		id: q486539294
		objId: 486539294
		x: 34
		y: 128
		width: 92
		height: 27
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/62#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiButton
	{
		id: q486539295
		objId: 486539295
		x: 33
		y: 221
		width: 92
		height: 39
		qm_BorderWidth: 2
		qm_ImageSource: "image://QSmartImageProvider/62#2#4#128#0#0"
		qm_Border.top: 2
		qm_Border.bottom: 2
		qm_Border.right: 2
		qm_Border.left: 2
		qm_FillColor: "#ffdedbde"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiIOField
	{
		id: q33554455
		objId: 33554455
		x: 240
		y: 222
		width: 53
		height: 38
		qm_BorderWidth: 2
		qm_RectangleBorder.width:2
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_FocusWidth: 0
		qm_FocusColor: "#00000000"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544344
		objId: 335544344
		x: 471
		y: 174
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544345
		objId: 335544345
		x: 471
		y: 206
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435525
		objId: 268435525
		x: 491
		y: 166
		width: 87
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435526
		objId: 268435526
		x: 492
		y: 201
		width: 72
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 3
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
}
