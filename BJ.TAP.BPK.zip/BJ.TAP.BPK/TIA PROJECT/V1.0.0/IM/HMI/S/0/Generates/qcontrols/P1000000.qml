﻿import QtQuick 2.7
import "qrc:/"
IGuiPage
{
	id: q16777216
	objId: 16777216
	x: 0
	y: 0
	width: 800
	height: 480
	IGuiGraphicView
	{
		id: q301989895
		objId: 301989895
		x: 708
		y: 36
		width: 56
		height: 48
		qm_Transparent : true 
		qm_ImageWidth: 56
		qm_ImageHeight: 48
		qm_SourceSizeWidth: 56
		qm_SourceSizeHeight: 48
	}
	IGuiGraphicView
	{
		id: q301989888
		objId: 301989888
		x: 527
		y: 279
		width: 37
		height: 44
		qm_Transparent : true 
		qm_ImageWidth: 37
		qm_ImageHeight: 44
		qm_SourceSizeWidth: 37
		qm_SourceSizeHeight: 44
	}
	IGuiQmlRectangle
	{
		id: q671088649
		objId: 671088649
		x: 0
		y: 461
		width: 799
		height: 18
		qm_BorderWidth: 1
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 799
		qm_RectangleHeight: 18
	}
	IGuiQmlRectangle
	{
		id: q671088650
		objId: 671088650
		x: 0
		y: 0
		width: 18
		height: 479
		qm_BorderWidth: 0
		qm_TextColor: "#ffffffff"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 18
		qm_RectangleHeight: 479
	}
	IGuiQmlRectangle
	{
		id: q671088651
		objId: 671088651
		x: 782
		y: 0
		width: 18
		height: 479
		qm_BorderWidth: 0
		qm_TextColor: "#ffffffff"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 18
		qm_RectangleHeight: 479
	}
	IGuiQmlRectangle
	{
		id: q671088652
		objId: 671088652
		x: 7
		y: 0
		width: 786
		height: 18
		qm_BorderWidth: 0
		qm_TextColor: "#ff000000"
		qm_FillColor: "#ff0000ff"
		qm_RectangleWidth: 786
		qm_RectangleHeight: 18
	}
	IGuiGraphicView
	{
		id: q301989889
		objId: 301989889
		x: 67
		y: 23
		width: 160
		height: 91
		qm_Transparent : true 
		qm_ImageWidth: 160
		qm_ImageHeight: 91
		qm_SourceSizeWidth: 160
		qm_SourceSizeHeight: 91
	}
	IGuiTextField
	{
		id: q268435465
		objId: 268435465
		x: 19
		y: 114
		width: 254
		height: 28
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435466
		objId: 268435466
		x: 93
		y: 138
		width: 105
		height: 28
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicView
	{
		id: q301989890
		objId: 301989890
		x: 424
		y: 332
		width: 68
		height: 125
		qm_Transparent : true 
		qm_ImageWidth: 68
		qm_ImageHeight: 125
		qm_SourceSizeWidth: 68
		qm_SourceSizeHeight: 125
	}
	IGuiGraphicView
	{
		id: q301989891
		objId: 301989891
		x: 521
		y: 304
		width: 166
		height: 157
		qm_Transparent : true 
		qm_ImageWidth: 166
		qm_ImageHeight: 157
		qm_SourceSizeWidth: 166
		qm_SourceSizeHeight: 157
	}
	IGuiGraphicView
	{
		id: q301989892
		objId: 301989892
		x: 682
		y: 252
		width: 101
		height: 55
		qm_Transparent : true 
		qm_ImageWidth: 101
		qm_ImageHeight: 55
		qm_SourceSizeWidth: 101
		qm_SourceSizeHeight: 55
	}
	IGuiGraphicView
	{
		id: q301989893
		objId: 301989893
		x: 490
		y: 414
		width: 36
		height: 55
		qm_Transparent : true 
		qm_ImageWidth: 36
		qm_ImageHeight: 55
		qm_SourceSizeWidth: 36
		qm_SourceSizeHeight: 55
	}
	IGuiGraphicView
	{
		id: q301989894
		objId: 301989894
		x: 163
		y: 407
		width: 37
		height: 43
		qm_Transparent : true 
		qm_ImageWidth: 37
		qm_ImageHeight: 43
		qm_SourceSizeWidth: 37
		qm_SourceSizeHeight: 43
	}
	IGuiGraphicView
	{
		id: q301989896
		objId: 301989896
		x: 70
		y: 395
		width: 62
		height: 64
		qm_Transparent : true 
		qm_ImageWidth: 62
		qm_ImageHeight: 64
		qm_SourceSizeWidth: 62
		qm_SourceSizeHeight: 64
	}
	IGuiGraphicView
	{
		id: q301989897
		objId: 301989897
		x: 328
		y: 332
		width: 68
		height: 125
		qm_Transparent : true 
		qm_ImageWidth: 68
		qm_ImageHeight: 125
		qm_SourceSizeWidth: 68
		qm_SourceSizeHeight: 125
	}
	IGuiGraphicView
	{
		id: q301989898
		objId: 301989898
		x: 231
		y: 332
		width: 68
		height: 125
		qm_Transparent : true 
		qm_ImageWidth: 68
		qm_ImageHeight: 125
		qm_SourceSizeWidth: 68
		qm_SourceSizeHeight: 125
	}
	IGuiGraphicView
	{
		id: q301989901
		objId: 301989901
		x: 394
		y: 414
		width: 34
		height: 55
		qm_Transparent : true 
		qm_ImageWidth: 34
		qm_ImageHeight: 55
		qm_SourceSizeWidth: 34
		qm_SourceSizeHeight: 55
	}
	IGuiGraphicView
	{
		id: q301989899
		objId: 301989899
		x: 297
		y: 414
		width: 34
		height: 55
		qm_Transparent : true 
		qm_ImageWidth: 34
		qm_ImageHeight: 55
		qm_SourceSizeWidth: 34
		qm_SourceSizeHeight: 55
	}
	IGuiGraphicView
	{
		id: q301989900
		objId: 301989900
		x: 132
		y: 414
		width: 102
		height: 55
		qm_Transparent : true 
		qm_ImageWidth: 102
		qm_ImageHeight: 55
		qm_SourceSizeWidth: 102
		qm_SourceSizeHeight: 55
	}
	IGuiGraphicView
	{
		id: q301989902
		objId: 301989902
		x: 18
		y: 414
		width: 54
		height: 55
		qm_Transparent : true 
		qm_ImageWidth: 54
		qm_ImageHeight: 55
		qm_SourceSizeWidth: 54
		qm_SourceSizeHeight: 55
	}
	IGuiBar
	{
		id: q50331648
		objId: 50331648
		x: 527
		y: 307
		width: 151
		height: 150
		qm_Transparent : true 
		qm_Font.pixelSize: 17
		qm_Font.family: "Tahoma"
		qm_BorderWidth: 1
		qm_RectangleBorder.color:"#ff000000"
		qm_TextColor: "#ff3165ff"
		flowbarorientation: 0
		qm_segmentBar: 0
		barscaleplacement: 2
		barmarkerplacement: 0
		scaleposition: Qt.point(13,1)
		scaleheight: 127
		scalewidth: 137
		scalerectwidth: 137
		scalerectheight: 148
		scalelabelcolor: "#ff000000"
		scaleorientation: 2
		scalepinwidth: 0
		scalepinheight: 0
		scalelabelwidth: 143
		scalelabelheight: 21
		scalemunitwidth: 0
		scaleinterval: 10
		scalelowvalue: 0.000000
		scalehighvalue: 100.000000
		scalelabellength: 12
		scaledecimalplaceno: 0
		scaleincrementlabelmark: 2
		scalesubdivisioncount: 5
		scaledetails: 1
		scalemeasurementunitid: -1
		scaleenlarge: 0
		bararrowtailwidth: 8
	}
	IGuiGraphicView
	{
		id: q301989903
		objId: 301989903
		x: 626
		y: 253
		width: 57
		height: 53
		qm_Transparent : true 
		qm_ImageWidth: 57
		qm_ImageHeight: 53
		qm_SourceSizeWidth: 57
		qm_SourceSizeHeight: 53
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544321
		objId: 335544321
		x: 292
		y: 335
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544322
		objId: 335544322
		x: 292
		y: 357
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544323
		objId: 335544323
		x: 390
		y: 336
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544324
		objId: 335544324
		x: 390
		y: 358
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544325
		objId: 335544325
		x: 487
		y: 335
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544326
		objId: 335544326
		x: 487
		y: 357
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544327
		objId: 335544327
		x: 688
		y: 377
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544328
		objId: 335544328
		x: 688
		y: 429
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544329
		objId: 335544329
		x: 688
		y: 399
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435467
		objId: 268435467
		x: 713
		y: 429
		width: 69
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435468
		objId: 268435468
		x: 715
		y: 398
		width: 63
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435469
		objId: 268435469
		x: 714
		y: 377
		width: 63
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544330
		objId: 335544330
		x: 688
		y: 357
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435470
		objId: 268435470
		x: 714
		y: 357
		width: 68
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435471
		objId: 268435471
		x: 714
		y: 336
		width: 62
		height: 18
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544331
		objId: 335544331
		x: 688
		y: 336
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiTextField
	{
		id: q268435472
		objId: 268435472
		x: 714
		y: 303
		width: 62
		height: 32
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiGraphicIOFieldOutput
	{
		id: q335544332
		objId: 335544332
		x: 688
		y: 303
		width: 20
		height: 20
		qm_Transparent : true 
		qm_ImageWidth: 20
		qm_ImageHeight: 20
		qm_SourceSizeWidth: 20
		qm_SourceSizeHeight: 20
	}
	IGuiButton
	{
		id: q486539290
		objId: 486539290
		x: 698
		y: 26
		width: 75
		height: 65
		qm_BorderCornerRadius: 20
		qm_BorderWidth: 4
		qm_ImageSource: "image://QSmartImageProvider/43#2#4#128#0#0"
		qm_Border.top: 22
		qm_Border.bottom: 22
		qm_Border.right: 22
		qm_Border.left: 22
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_ValueVarTextAlignmentVertical: Text.AlignVCenter
		qm_Anchors.bottomMargin: 4
		qm_Anchors.leftMargin: 4
		qm_Anchors.rightMargin: 4
		qm_Anchors.topMargin: 4
		qm_FocusWidth: 2
		qm_FocusColor: "#ff0079ce"
	}
	IGuiTextField
	{
		id: q268435473
		objId: 268435473
		x: 695
		y: 91
		width: 83
		height: 25
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554437
		objId: 33554437
		x: 441
		y: 247
		width: 54
		height: 32
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435474
		objId: 268435474
		x: 463
		y: 220
		width: 154
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554438
		objId: 33554438
		x: 149
		y: 354
		width: 69
		height: 32
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435475
		objId: 268435475
		x: 149
		y: 329
		width: 75
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554439
		objId: 33554439
		x: 64
		y: 341
		width: 73
		height: 32
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435476
		objId: 268435476
		x: 66
		y: 313
		width: 69
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435477
		objId: 268435477
		x: 143
		y: 380
		width: 80
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435478
		objId: 268435478
		x: 83
		y: 368
		width: 37
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435479
		objId: 268435479
		x: 495
		y: 250
		width: 27
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554440
		objId: 33554440
		x: 529
		y: 247
		width: 90
		height: 32
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435480
		objId: 268435480
		x: 617
		y: 250
		width: 39
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiIOField
	{
		id: q33554441
		objId: 33554441
		x: 26
		y: 245
		width: 148
		height: 32
		qm_RectangleBorder.width:0
		qm_RectangleBorder.color:"#ff000000"
		qm_FillColor: "#ffffffff"
		qm_TextColor: "#ff000000"
		qm_ValueVarTextAlignmentHorizontal: Text.AlignHCenter
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435481
		objId: 268435481
		x: 73
		y: 217
		width: 55
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
	IGuiTextField
	{
		id: q268435482
		objId: 268435482
		x: 77
		y: 274
		width: 46
		height: 27
		qm_Transparent : true 
		qm_TextColor: "#ff000000"
		qm_Anchors.bottomMargin: 2
		qm_Anchors.leftMargin: 2
		qm_Anchors.rightMargin: 2
		qm_Anchors.topMargin: 2
	}
}
